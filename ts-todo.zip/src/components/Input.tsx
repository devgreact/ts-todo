const Input = () => {
  return <div>Input</div>;
};

export default Input;
